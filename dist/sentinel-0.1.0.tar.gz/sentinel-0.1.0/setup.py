# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sentinel']

package_data = \
{'': ['*']}

install_requires = \
['colorama>=0.4.4,<0.5.0', 'shellingham>=1.4.0,<2.0.0', 'typer>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['start = main:main']}

setup_kwargs = {
    'name': 'sentinel',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'AJITH-klepsydra',
    'author_email': 'ajithpmuralidharan01@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
